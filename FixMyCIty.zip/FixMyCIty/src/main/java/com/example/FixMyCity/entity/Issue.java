package com.example.FixMyCity.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Entity
@Table(name = "issues")
@Data
@Getter
@Setter
public class Issue {

    @Id
    @GeneratedValue
    private UUID id;

    private String title;
    private String description;

    @Enumerated(EnumType.STRING)
    private Category category;

    @Enumerated(EnumType.STRING)
    private Status status = Status.OPEN;

    private Double latitude;
    private Double longitude;
    private String address;

    private LocalDateTime createdAt = LocalDateTime.now();

    @ManyToOne
    @JoinColumn(name = "user_id")
    @ToString.Exclude
    @JsonIgnore
    private User createdBy;

    @OneToMany(mappedBy = "issue", cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<IssueImage> images = new ArrayList<>();


}






