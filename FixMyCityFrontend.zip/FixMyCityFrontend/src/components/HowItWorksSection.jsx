import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';

export default function HowItWorksSection () {
  const steps = [
    {
      number: "01",
      title: "Spot an Issue",
      description: "Notice a pothole, broken streetlight, or any civic problem in your area.",
      icon: AlertCircle
    },
    {
      number: "02",
      title: "Report It",
      description: "Take a photo, add details, and submit your report through our easy-to-use app.",
      icon: Camera
    },
    {
      number: "03",
      title: "Track Progress",
      description: "Monitor the status of your report and receive updates as it gets resolved.",
      icon: TrendingUp
    },
    {
      number: "04",
      title: "See Results",
      description: "Watch as your city gets better, one resolved issue at a time.",
      icon: CheckCircle
    }
  ];

  return (
    <div id="how-it-works" className="py-24 bg-gradient-to-br from-orange-50 via-white to-orange-50">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold text-gray-900 sm:text-5xl">
            How It <span className="text-transparent bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text">Works</span>
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-gray-600">
            Four simple steps to make a difference in your community
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-24 left-full w-full h-0.5 bg-gradient-to-r from-orange-300 to-transparent"></div>
              )}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-20 h-20 mb-6 shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl">
                  <step.icon className="w-10 h-10 text-white" />
                </div>
                <div className="mb-4 text-5xl font-bold text-orange-200">{step.number}</div>
                <h3 className="mb-3 text-2xl font-bold text-gray-900">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};