import React from 'react';
import { Map, MapPin, ImageIcon } from 'lucide-react';

const MapView = ({ issues, selectedIssue, onSelectIssue }) => {
  const openInGoogleMaps = (lat, lng) => {
    window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-orange-700 mb-4">Issues Map View</h2>
      
      <div className="bg-white rounded-xl shadow-lg p-6 border border-orange-200">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 max-h-96 overflow-y-auto space-y-3">
            <h3 className="font-semibold text-lg text-orange-600 sticky top-0 bg-white pb-2">
              Select an Issue
            </h3>
            {issues.map((issue) => (
              <div
                key={issue.id}
                onClick={() => onSelectIssue(issue)}
                className={`p-3 border rounded-lg cursor-pointer transition ${
                  selectedIssue?.id === issue.id
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-200 hover:border-orange-300'
                }`}
              >
                <h4 className="font-semibold text-sm">{issue.title}</h4>
                <p className="text-xs text-gray-600 mt-1">{issue.category}</p>
                {issue.imageUrls && issue.imageUrls.length > 0 && (
                  <div className="flex items-center gap-1 mt-1">
                    <ImageIcon size={12} className="text-gray-500" />
                    <span className="text-xs text-gray-500">
                      {issue.imageUrls.length} image(s)
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="lg:col-span-2">
            {selectedIssue ? (
              <div className="space-y-4">
                <div className="border-2 border-orange-300 rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="400"
                    frameBorder="0"
                    src={`https://www.openstreetmap.org/export/embed.html?bbox=${selectedIssue.longitude-0.01},${selectedIssue.latitude-0.01},${selectedIssue.longitude+0.01},${selectedIssue.latitude+0.01}&layer=mapnik&marker=${selectedIssue.latitude},${selectedIssue.longitude}`}
                    style={{ border: 0 }}
                  ></iframe>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-xl font-bold text-orange-700">{selectedIssue.title}</h3>
                  <p className="text-gray-700 mt-2">{selectedIssue.description}</p>
                  
                  {selectedIssue.status && (
                    <p className={`mt-2 text-sm font-medium ${
                      selectedIssue.status === 'RESOLVED' ? 'text-green-600' :
                      selectedIssue.status === 'IN_PROGRESS' ? 'text-blue-600' :
                      'text-yellow-600'
                    }`}>
                      Status: {selectedIssue.status.replace('_', ' ')}
                    </p>
                  )}
                  
                  {selectedIssue.imageUrls && selectedIssue.imageUrls.length > 0 && (
                    <div className="mt-3">
                      <div className="flex items-center gap-2 mb-2">
                        <ImageIcon size={18} className="text-gray-600" />
                        <span className="font-medium text-gray-700">Images:</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {selectedIssue.imageUrls.map((url, index) => (
                          <img
                            key={index}
                            src={url}
                            alt={`${selectedIssue.title} - Image ${index + 1}`}
                            className="w-full h-40 object-cover rounded-lg cursor-pointer hover:opacity-90 transition"
                            onClick={() => window.open(url, '_blank')}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="mt-3 space-y-1">
                    <p className="text-sm"><strong>Category:</strong> {selectedIssue.category}</p>
                    <p className="text-sm"><strong>Reported by:</strong> {selectedIssue.createdBy}</p>
                    <p className="text-sm"><strong>Coordinates:</strong> {selectedIssue.latitude}, {selectedIssue.longitude}</p>
                  </div>
                  <button
                    onClick={() => openInGoogleMaps(selectedIssue.latitude, selectedIssue.longitude)}
                    className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 flex items-center gap-2"
                  >
                    <MapPin size={18} /> Open in Google Maps
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-96 text-gray-500">
                <div className="text-center">
                  <Map size={64} className="mx-auto mb-4 text-gray-300" />
                  <p className="text-lg">Select an issue to view on map</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapView;