import React from 'react';
import IssueCard from './IssueCard';

const IssuesList = ({ issues, currentView, onStatusUpdate }) => {
  if (issues.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p className="text-lg">
          {currentView === "my" ? "You haven't reported any issues yet" : "No issues reported yet"}
        </p>
        <p className="text-sm mt-2">Click "Add Issue" to report a problem</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
      {issues.map((issue) => (
        <IssueCard
          key={issue.id}
          issue={issue}
          onStatusUpdate={onStatusUpdate}
          isMyIssue={currentView === "my"}
        />
      ))}
    </div>
  );
};

export default IssuesList;