import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function HeroSection ({ onGetStarted }) {

const navigate=useNavigate();

const goToLogin=()=>{
  navigate("/login");
}

  return (
    <div className="relative flex items-center justify-center min-h-screen pt-24 overflow-hidden bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute bg-orange-200 rounded-full top-20 left-10 w-72 h-72 mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
        <div className="absolute bg-orange-300 rounded-full top-40 right-10 w-72 h-72 mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
        <div className="absolute bg-orange-400 rounded-full -bottom-8 left-1/2 w-72 h-72 mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative px-4 py-20 mx-auto text-center max-w-7xl sm:px-6 lg:px-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-6 bg-orange-100 rounded-full animate-fade-in">
          <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-medium text-orange-600">Making Cities Better, Together</span>
        </div>

        <h1 className="mb-6 text-5xl font-bold leading-tight text-gray-900 sm:text-6xl lg:text-7xl animate-fade-in-up">
          Transform Your City,
          <br />
          <span className="text-transparent bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text">
            One Report at a Time
          </span>
        </h1>

        <p className="max-w-3xl mx-auto mb-10 text-xl text-gray-600 animate-fade-in-up animation-delay-200">
          Empower your community by reporting civic issues instantly. From potholes to streetlights, 
          help make your city a better place for everyone.
        </p>

        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row animate-fade-in-up animation-delay-400">
          <button
            onClick={goToLogin}
            className="flex items-center gap-2 px-8 py-4 text-lg font-semibold text-white transition-all rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:shadow-2xl hover:scale-105"
          >
            Start Reporting Now
            <ArrowRight className="w-5 h-5" />
          </button>
          <button className="px-8 py-4 text-lg font-semibold text-orange-600 transition-all border-2 border-orange-600 rounded-full hover:bg-orange-50">
            Watch Demo
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-8 mt-20 md:grid-cols-4 animate-fade-in-up animation-delay-600">
          <div className="p-6 transition-shadow bg-white shadow-xl rounded-2xl hover:shadow-2xl">
            <div className="mb-2 text-4xl font-bold text-orange-600">10K+</div>
            <div className="font-medium text-gray-600">Issues Resolved</div>
          </div>
          <div className="p-6 transition-shadow bg-white shadow-xl rounded-2xl hover:shadow-2xl">
            <div className="mb-2 text-4xl font-bold text-orange-600">50+</div>
            <div className="font-medium text-gray-600">Cities Active</div>
          </div>
          <div className="p-6 transition-shadow bg-white shadow-xl rounded-2xl hover:shadow-2xl">
            <div className="mb-2 text-4xl font-bold text-orange-600">25K+</div>
            <div className="font-medium text-gray-600">Active Users</div>
          </div>
          <div className="p-6 transition-shadow bg-white shadow-xl rounded-2xl hover:shadow-2xl">
            <div className="mb-2 text-4xl font-bold text-orange-600">95%</div>
            <div className="font-medium text-gray-600">Satisfaction Rate</div>
          </div>
        </div>
      </div>
    </div>
  );
};