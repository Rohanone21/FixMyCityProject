import React from 'react';
import { MapPin, Image as ImageIcon } from 'lucide-react';

const IssueCard = ({ issue, onStatusUpdate, isMyIssue = false }) => {
  const openInGoogleMaps = (lat, lng) => {
    window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
  };

  const handleStatusChange = async (newStatus) => {
    if (onStatusUpdate) {
      await onStatusUpdate(issue.id, newStatus);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow p-4 border border-orange-200">
      <div className="flex justify-between items-start">
        <h2 className="text-xl font-semibold text-orange-700">{issue.title}</h2>
        {isMyIssue && issue.status && (
          <select
            value={issue.status || 'PENDING'}
            onChange={(e) => handleStatusChange(e.target.value)}
            className="text-sm border rounded px-2 py-1 bg-gray-50"
          >
            <option value="PENDING">Pending</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
          </select>
        )}
      </div>
      
      <p className="text-gray-700 mt-1">{issue.description}</p>
      <p className="mt-2 text-sm text-orange-600 font-semibold">
        Category: {issue.category}
      </p>
      {issue.status && (
        <p className={`text-sm font-medium mt-1 ${
          issue.status === 'RESOLVED' ? 'text-green-600' :
          issue.status === 'IN_PROGRESS' ? 'text-blue-600' :
          'text-yellow-600'
        }`}>
          Status: {issue.status.replace('_', ' ')}
        </p>
      )}
      <p className="text-xs text-gray-500 mt-1">
        Reported by: {issue.createdBy}
      </p>
      <p className="text-xs text-gray-400 mt-1">
        Coordinates: {issue.latitude}, {issue.longitude}
      </p>
      
      {issue.imageUrls && issue.imageUrls.length > 0 && (
        <div className="mt-3">
          <div className="flex items-center gap-2 mb-2">
            <ImageIcon size={14} className="text-gray-600" />
            <span className="text-xs font-medium text-gray-700">Images:</span>
          </div>
          <div className="space-y-2">
            {issue.imageUrls.map((url, index) => (
              <img
                key={index}
                src={url}
                alt={`${issue.title} - Image ${index + 1}`}
                className="w-full h-32 object-cover rounded-lg cursor-pointer hover:opacity-90 transition"
                onClick={() => window.open(url, '_blank')}
              />
            ))}
          </div>
        </div>
      )}
      
      <button
        onClick={() => openInGoogleMaps(issue.latitude, issue.longitude)}
        className="mt-3 text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded hover:bg-blue-200 flex items-center gap-1 w-full justify-center"
      >
        <MapPin size={14} /> View on Map
      </button>
    </div>
  );
};

export default IssueCard;