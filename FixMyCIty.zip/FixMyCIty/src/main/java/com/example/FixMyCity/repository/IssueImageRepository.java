package com.example.FixMyCity.repository;


import com.example.FixMyCity.entity.IssueImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface IssueImageRepository extends JpaRepository<IssueImage, UUID> {
  List<IssueImage> findByIssueId(UUID issueId);
}

