package com.example.FixMyCity.controller;

import com.example.FixMyCity.DTO.CreateIssueRequest;
import com.example.FixMyCity.DTO.IssueResponse;
import com.example.FixMyCity.DTO.UpdateStatusRequest;
import com.example.FixMyCity.Error.ResourceNotFoundException;
import com.example.FixMyCity.entity.Category;
import com.example.FixMyCity.entity.Issue;
import com.example.FixMyCity.entity.IssueImage;
import com.example.FixMyCity.entity.User;
import com.example.FixMyCity.repository.IssueRepository;
import com.example.FixMyCity.repository.UserRepository;
import com.example.FixMyCity.service.IssueService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/issues")
public class IssueController {

    @Autowired
    private  IssueService issueService;
    @Autowired
    private IssueRepository issueRepository;
    @Autowired
    private UserRepository userRepository;


    @Operation(
            summary = "Create a new issue",
            description = "Create an issue with details and a single image upload"
    )
    @PostMapping(value = "/create", consumes = "multipart/form-data")
    public ResponseEntity<Issue> createIssue(

            @Parameter(description = "Issue Title", required = true)
            @RequestParam String title,

            @Parameter(description = "Issue Description", required = true)
            @RequestParam String description,

            @Parameter(description = "Issue Category", required = true)
            @RequestParam String category,

            @Parameter(description = "Latitude", required = true)
            @RequestParam double latitude,

            @Parameter(description = "Longitude", required = true)
            @RequestParam double longitude,

            @Parameter(description = "Address", required = true)
            @RequestParam String address,

            @Parameter(
                    name = "image",
                    description = "Upload one image",
                    required = true,
                    content = @Content(
                            mediaType = "multipart/form-data",
                            schema = @Schema(type = "string", format = "binary")
                    )
            )
            @RequestPart("image") MultipartFile image,

            Principal principal
    ) throws IOException {

        String email = principal.getName();

        CreateIssueRequest data = new CreateIssueRequest();
        data.setTitle(title);
        data.setDescription(description);
        data.setCategory(Category.valueOf(category));
        data.setLatitude(latitude);
        data.setLongitude(longitude);
        data.setAddress(address);



        Issue response = issueService.createIssue(data, image, email);

        return ResponseEntity.ok(response);
    }


    @GetMapping("/getAll")
    public ResponseEntity<?> getAllIssues() {
        try {
            List<Issue> list = issueRepository.findAll();
            System.out.println("list"+list);
            List<IssueResponse> responseList = list.stream()
                    .map(this::toIssueResponse)
                    .toList();

            return ResponseEntity.ok(responseList);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
    public IssueResponse toIssueResponse(Issue issue) {
        IssueResponse response = new IssueResponse();

        response.setId(issue.getId());
        response.setTitle(issue.getTitle());
        response.setDescription(issue.getDescription());
        response.setCategory(String.valueOf(issue.getCategory()));
        response.setLatitude(issue.getLatitude());
        response.setLongitude(issue.getLongitude());
        response.setCreatedBy(issue.getCreatedBy().getEmail());
        response.setStatus(issue.getStatus().name());


        if (issue.getImages() == null || issue.getImages().isEmpty()) {
            response.setImageUrls(null);
        } else {
            List<String> urls = issue.getImages()
                    .stream()
                    .map(IssueImage::getImageUrl)
                    .toList();

            response.setImageUrls(urls);
        }

        return response;
    }

    @PostMapping("/{id}/status")
    @Operation(summary = "Update issue status")
    public ResponseEntity<?> updateIssueStatus(
            @PathVariable UUID id,
            @RequestBody UpdateStatusRequest request
    ) {
        try {
            Issue updatedIssue = issueService.updateStatus(id, request.getStatus());
            return ResponseEntity.ok(updatedIssue);

        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(404).body(ex.getMessage());
        }
    }


    @GetMapping("/{id}")
    @Operation(summary = "Get issue by id")
    public ResponseEntity<?> getSingleIssue(@PathVariable UUID id){
        try {
            Issue issue= issueService.getIssueById(id);
            return  ResponseEntity.ok(issue);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @GetMapping("/my-issues/{id}")
    @Operation(summary = "Get all issues created by logged-in user")
    public ResponseEntity<?> getMyIssues(@PathVariable UUID id) {
        User user=userRepository.getById(id);

        List<Issue> issues = issueService.getByUser(user);
        List<IssueResponse> res = issues.stream().map(this::toIssueResponse).toList();
        return ResponseEntity.ok(res);
    }




}

