import { useState } from 'react'
import LandingPage from './pages/LandingPage'
import ProtectedLayout from "./layout/ProtectedLayout";
import AuthLayout from "./layout/AuthLayout";
import {useAuth} from "./hooks/useAuth"
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginPage from './pages/Login';
import SignupPage from './pages/Signup';
import DashboardPage from './pages/Dashboard';

function App() {

const { auth, login, logout } = useAuth();

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage></LandingPage>}> </Route>

        {/* AUTH ROUTES */}
        <Route element={<AuthLayout isAuthenticated={auth} />}>
          <Route path="/login" element={<LoginPage login={login} />} />
          <Route path="/signup" element={<SignupPage />} />
        </Route>


        {/* PROTECTED ROUTES */}
        {/* <Route element={<ProtectedLayout isAuthenticated={auth} />}> */}
          <Route path="/dashboard" element={<DashboardPage logout={logout} />} />
          {/* <Route path="/profile" element={<Profile />} /> */}
        {/* </Route> */}


      </Routes>

       
    </BrowserRouter>
  )
}

export default App
