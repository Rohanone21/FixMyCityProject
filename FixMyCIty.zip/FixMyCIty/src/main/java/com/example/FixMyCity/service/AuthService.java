package com.example.FixMyCity.service;


import com.example.FixMyCity.DTO.LoginRequest;
import com.example.FixMyCity.DTO.SignupRequest;
import com.example.FixMyCity.DTO.AuthResponse;
import com.example.FixMyCity.Error.ResourceNotFoundException;
import com.example.FixMyCity.entity.User;
import com.example.FixMyCity.repository.UserRepository;
import com.example.FixMyCity.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

      @Autowired
      private UserRepository userRepo;
      @Autowired
    private PasswordEncoder passwordEncoder;
      @Autowired
    private JwtUtil jwtUtil;
      @Autowired
    private AuthenticationManager authenticationManager;


    public AuthResponse signup(SignupRequest request) {

        if (userRepo.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        userRepo.save(user);

        String token = jwtUtil.generateToken(user.getEmail());

        return new AuthResponse(token, user.getEmail(),user.getId());
    }

    public AuthResponse login(LoginRequest request) {

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );
        Optional<User> user= Optional.ofNullable(userRepo.findByEmail(request.getEmail()).orElseThrow(
                () -> new ResourceNotFoundException("User does not exist")
        ));

        String token = jwtUtil.generateToken(request.getEmail());

        return new AuthResponse(token, request.getEmail(),user.get().getId());
    }

}
