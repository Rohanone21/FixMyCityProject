import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { signUp } from "../services/AuthService";

export default function SignupPage() {
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading,setLoading]=useState(false)

  const goToLogin = () => {
    navigate("/login");
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true)

    if (!fullName || !email || !password) {
      alert("All fields are required");
      return;
    }

    try {
      const data = { 
        name:fullName, 
        email:email, 
        password:password 
    };
      const response = await signUp(data);

      console.log("Signup success:", response);

      alert("Account created successfully!");
      navigate("/login");
      setLoading(false);
    } catch (error) {
      console.error("Signup error:", error);
      alert("Signup failed. Please try again.");
      setLoading(false)
    }
  };

  return (
    <div className="flex h-screen">
      {/* Left side */}
      <div className="w-1/2 bg-white flex flex-col items-center justify-center p-10">
        <img src="logo1.png" alt="App Logo" className="w-32 h-32 object-contain mb-4" />
        <h1 className="text-4xl font-bold text-orange-600">FixMyCity</h1>
      </div>

      {/* Right side */}
      <div className="w-1/2 bg-orange-500 flex items-center justify-center p-10 text-white">
        <form
          className="bg-white text-gray-800 p-8 rounded-2xl shadow-md w-96"
          onSubmit={handleSignup}
        >
          <h2 className="text-2xl font-semibold mb-6 text-center text-orange-600">
            Create Account
          </h2>

          <label className="block mb-2 font-medium">Full Name</label>
          <input
            type="text"
            className="w-full p-2 border rounded mb-4"
            placeholder="Enter your name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />

          <label className="block mb-2 font-medium">Email</label>
          <input
            type="email"
            className="w-full p-2 border rounded mb-4"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label className="block mb-2 font-medium">Password</label>
          <input
            type="password"
            className="w-full p-2 border rounded mb-6"
            placeholder="Create a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button
  type="submit"
  disabled={loading}
  className={`w-full text-white py-2 rounded transition 
    ${loading ? "bg-gray-400 cursor-not-allowed" : "bg-orange-600 hover:bg-orange-700"}`}
>
  {loading ? "Loading..." : "Sign Up"}
</button>


          <div className="flex p-2 pl-9">
            Already Have An Account?
            <div
              className="text-blue-500 hover:cursor-pointer pl-1"
              onClick={goToLogin}
            >
              Login
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
