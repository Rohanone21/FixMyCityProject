import React, { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import IssueDialog from "./components/IssueDialog";
import MapView from "./components/MapView";
import IssuesList from "./components/IssuesList";

export default function DashboardPage() {
  const [issues, setIssues] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [currentView, setCurrentView] = useState("all");
  const [selectedIssue, setSelectedIssue] = useState(null);

  const fetchIssues = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:8081/api/issues/getAll", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
      console.log("Fetched Issues:", data);
      setIssues(data);
    } catch (error) {
      console.error("Fetch Issues Error", error);
    }
  };

  useEffect(() => {
    fetchIssues();
  }, []);

  const getMyIssues = () => {
    const userEmail = localStorage.getItem("userEmail");
    return issues.filter(issue => issue.createdBy === userEmail);
  };

  const handleAddIssue = async (formData) => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      
      const formDataToSend = new FormData();
      formDataToSend.append("title", formData.title);
      formDataToSend.append("description", formData.description);
      formDataToSend.append("category", formData.category);
      formDataToSend.append("latitude", formData.latitude);
      formDataToSend.append("longitude", formData.longitude);
      formDataToSend.append("address", formData.address);
      formDataToSend.append("image", formData.image);

      const response = await fetch("http://localhost:8081/api/issues/create", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formDataToSend,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to create issue");
      }

      setLoading(false);
      setOpenDialog(false);
      
      fetchIssues();
      alert("Issue created successfully!");
    } catch (error) {
      console.error("Create Issue Error", error);
      alert("Failed to create issue: " + error.message);
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (issueId, newStatus) => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`http://localhost:8081/api/issues/${issueId}/status`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to update status");
      }

      // Update local state
      setIssues(prevIssues =>
        prevIssues.map(issue =>
          issue.id === issueId ? { ...issue, status: newStatus } : issue
        )
      );
      
      alert("Status updated successfully!");
    } catch (error) {
      console.error("Update Status Error", error);
      alert("Failed to update status: " + error.message);
    }
  };

  const renderContent = () => {
    if (currentView === "map") {
      return (
        <MapView
          issues={issues}
          selectedIssue={selectedIssue}
          onSelectIssue={setSelectedIssue}
        />
      );
    }

    const displayIssues = currentView === "my" ? getMyIssues() : issues;
    
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold text-orange-700 mb-4">
          {currentView === "my" ? "My Reported Issues" : "All Reported Issues"}
        </h2>
        <IssuesList
          issues={displayIssues}
          currentView={currentView}
          onStatusUpdate={handleStatusUpdate}
        />
      </div>
    );
  };

  return (
    <div className="bg-orange-50 min-h-screen">
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        onAddIssueClick={() => setOpenDialog(true)}
      />

      {renderContent()}

      <IssueDialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        onSubmit={handleAddIssue}
        loading={loading}
      />
    </div>
  );
}