import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';

export default function Footer () {
  return (
    <footer className="py-12 text-white bg-gray-900">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="grid gap-8 mb-8 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">FixMyCity</span>
            </div>
            <p className="text-gray-400">
              Empowering communities to create better cities together.
            </p>
          </div>

          <div>
            <h4 className="mb-4 font-bold text-orange-400">Product</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#features" className="transition-colors hover:text-orange-400">Features</a></li>
              <li><a href="#how-it-works" className="transition-colors hover:text-orange-400">How It Works</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Pricing</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-bold text-orange-400">Company</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="transition-colors hover:text-orange-400">About Us</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Blog</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Careers</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-bold text-orange-400">Legal</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="transition-colors hover:text-orange-400">Privacy Policy</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Terms of Service</a></li>
              <li><a href="#" className="transition-colors hover:text-orange-400">Cookie Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 pt-8 border-t border-gray-800 md:flex-row">
          <p className="text-sm text-gray-400">
            © 2025 FixMyCity. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-400 transition-colors hover:text-orange-400">Twitter</a>
            <a href="#" className="text-gray-400 transition-colors hover:text-orange-400">LinkedIn</a>
            <a href="#" className="text-gray-400 transition-colors hover:text-orange-400">Facebook</a>
            <a href="#" className="text-gray-400 transition-colors hover:text-orange-400">Instagram</a>
          </div>
        </div>
      </div>
    </footer>
  );
};