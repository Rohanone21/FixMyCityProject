import React from 'react';
import { Plus, List, Map, User } from 'lucide-react';

const Navbar = ({ currentView, setCurrentView, onAddIssueClick }) => {
  return (
    <nav className="bg-orange-600 text-white px-6 py-4 shadow-lg sticky top-0 z-50">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">FixMyCity Dashboard</h1>
        
        <div className="flex items-center gap-4">
          <button
            onClick={() => setCurrentView("all")}
            className={`px-4 py-2 rounded flex items-center gap-2 font-semibold transition ${
              currentView === "all" 
                ? "bg-white text-orange-600" 
                : "bg-orange-500 hover:bg-orange-400"
            }`}
          >
            <List size={18} /> All Issues
          </button>
          
          <button
            onClick={() => setCurrentView("my")}
            className={`px-4 py-2 rounded flex items-center gap-2 font-semibold transition ${
              currentView === "my" 
                ? "bg-white text-orange-600" 
                : "bg-orange-500 hover:bg-orange-400"
            }`}
          >
            <User size={18} /> My Issues
          </button>
          
          <button
            onClick={() => setCurrentView("map")}
            className={`px-4 py-2 rounded flex items-center gap-2 font-semibold transition ${
              currentView === "map" 
                ? "bg-white text-orange-600" 
                : "bg-orange-500 hover:bg-orange-400"
            }`}
          >
            <Map size={18} /> View on Map
          </button>
          
          <button
            onClick={onAddIssueClick}
            className="bg-green-500 text-white px-4 py-2 rounded flex items-center gap-2 font-semibold hover:bg-green-600"
          >
            <Plus /> Add Issue
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;