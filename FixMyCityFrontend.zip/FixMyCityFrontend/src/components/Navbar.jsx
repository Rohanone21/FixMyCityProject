import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';


export default function Navbar ({ onGetStarted, onLogin }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate=useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white shadow-lg py-3' 
        : 'bg-white/90 backdrop-blur-md py-4 mt-4'
    }`}>
      <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${
        isScrolled ? '' : 'bg-white rounded-full shadow-xl px-6'
      }`}>
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-transparent bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text">
              FixMyCity
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="items-center hidden gap-8 md:flex">
            <a href="#features" className="font-medium text-gray-700 transition-colors hover:text-orange-600">Features</a>
            <a href="#how-it-works" className="font-medium text-gray-700 transition-colors hover:text-orange-600">How It Works</a>
            <a href="#impact" className="font-medium text-gray-700 transition-colors hover:text-orange-600">Impact</a>
            <button
              onClick={onLogin}
              className="font-medium text-orange-600 transition-colors hover:text-orange-700"
            >
              Login
            </button>
            <button
              onClick={onGetStarted}
              className="flex items-center gap-2 px-6 py-2 font-medium text-white transition-all rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:shadow-lg hover:scale-105"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-gray-700 md:hidden hover:text-orange-600"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="bg-white border-t shadow-lg md:hidden">
          <div className="px-4 py-4 space-y-3">
            <a href="#features" className="block py-2 font-medium text-gray-700 hover:text-orange-600">Features</a>
            <a href="#how-it-works" className="block py-2 font-medium text-gray-700 hover:text-orange-600">How It Works</a>
            <a href="#impact" className="block py-2 font-medium text-gray-700 hover:text-orange-600">Impact</a>
            <button
              onClick={onLogin}
              className="block w-full py-2 font-medium text-left text-orange-600 hover:text-orange-700"
            >
              Login
            </button>
            <button
              onClick={onGetStarted}
              className="flex items-center justify-center w-full gap-2 px-6 py-3 font-medium text-white transition-all rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:shadow-lg"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};