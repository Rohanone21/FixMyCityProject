import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';

export default function FeaturesSection () {
  const features = [
    {
      icon: Camera,
      title: "Instant Reporting",
      description: "Snap a photo, add details, and submit in seconds. It's that simple.",
      gradient: "from-orange-500 to-orange-600"
    },
    {
      icon: MapPin,
      title: "Location Tracking",
      description: "Automatically detect and pin the exact location of civic issues.",
      gradient: "from-orange-600 to-orange-700"
    },
    {
      icon: TrendingUp,
      title: "Real-time Updates",
      description: "Track your report's progress from submission to resolution.",
      gradient: "from-orange-500 to-orange-600"
    },
    {
      icon: Users,
      title: "Community Driven",
      description: "Join thousands making a difference in their neighborhoods.",
      gradient: "from-orange-600 to-orange-700"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Your data is encrypted and protected with enterprise-grade security.",
      gradient: "from-orange-500 to-orange-600"
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Optimized for speed. Report issues without any lag or delays.",
      gradient: "from-orange-600 to-orange-700"
    }
  ];

  return (
    <div id="features" className="py-24 bg-white">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold text-gray-900 sm:text-5xl">
            Powerful Features for
            <span className="text-transparent bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text"> Better Cities</span>
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-gray-600">
            Everything you need to report, track, and resolve civic issues efficiently
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-8 transition-all duration-300 border border-orange-100 group bg-gradient-to-br from-orange-50 to-white rounded-2xl hover:shadow-2xl hover:-translate-y-2"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="mb-3 text-2xl font-bold text-gray-900">{feature.title}</h3>
              <p className="leading-relaxed text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};