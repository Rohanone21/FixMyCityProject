package com.example.FixMyCity.DTO;

import com.example.FixMyCity.entity.Status;
import lombok.Data;

@Data
public class UpdateStatusRequest {
    private Status status;
}
