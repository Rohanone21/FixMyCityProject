import React, { useState, useEffect, createContext, useContext } from 'react';
import { AlertCircle, MapPin, Camera, Send, LogOut, Home, PlusCircle, List, Menu, X, ArrowRight, CheckCircle, Users, TrendingUp, Shield, Zap, Globe } from 'lucide-react';

export default function ImpactSection ({onGetStarted}) {
  return (
    <div id="impact" className="py-24 text-white bg-gradient-to-r from-orange-600 to-orange-500">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold sm:text-5xl">
            Making Real Impact
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-orange-100">
            Join thousands of citizens who are transforming their cities every day
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          <div className="p-8 transition-all bg-white/10 backdrop-blur-lg rounded-2xl hover:bg-white/20">
            <Globe className="w-12 h-12 mb-4 text-orange-200" />
            <h3 className="mb-2 text-3xl font-bold">50+ Cities</h3>
            <p className="text-orange-100">Active across multiple countries</p>
          </div>
          <div className="p-8 transition-all bg-white/10 backdrop-blur-lg rounded-2xl hover:bg-white/20">
            <Users className="w-12 h-12 mb-4 text-orange-200" />
            <h3 className="mb-2 text-3xl font-bold">25K+ Users</h3>
            <p className="text-orange-100">Growing community of changemakers</p>
          </div>
          <div className="p-8 transition-all bg-white/10 backdrop-blur-lg rounded-2xl hover:bg-white/20">
            <CheckCircle className="w-12 h-12 mb-4 text-orange-200" />
            <h3 className="mb-2 text-3xl font-bold">10K+ Resolved</h3>
            <p className="text-orange-100">Issues fixed and counting</p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <button className="px-8 py-4 text-lg font-semibold text-orange-600 transition-all bg-white rounded-full hover:shadow-2xl hover:scale-105"
           onClick={onGetStarted}
          >
            Join the Movement
          </button>
        </div>
      </div>
    </div>
  );
};