package com.example.FixMyCity.service;


import com.example.FixMyCity.DTO.CreateIssueRequest;
import com.example.FixMyCity.DTO.IssueResponse;
import com.example.FixMyCity.Error.ResourceNotFoundException;
import com.example.FixMyCity.entity.Issue;
import com.example.FixMyCity.entity.IssueImage;
import com.example.FixMyCity.entity.Status;
import com.example.FixMyCity.entity.User;
import com.example.FixMyCity.repository.IssueImageRepository;
import com.example.FixMyCity.repository.IssueRepository;
import com.example.FixMyCity.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class IssueService {

    @Autowired
    private  IssueRepository issueRepo;
    @Autowired
    private IssueImageRepository imageRepo;
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private S3Service s3Service;


    public Issue createIssue(CreateIssueRequest request,
                                     MultipartFile image,
                                     String userEmail) throws IOException {

        User user = userRepo.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Issue issue = new Issue();
        issue.setTitle(request.getTitle());
        issue.setDescription(request.getDescription());
        issue.setCategory(request.getCategory());
        issue.setLatitude(request.getLatitude());
        issue.setLongitude(request.getLongitude());
        issue.setCreatedBy(user);
        issue.setStatus(Status.OPEN);

        Issue saved=issueRepo.save(issue);


        String imageUrl = s3Service.uploadFile(image);


        IssueImage issueImage = new IssueImage();
        issueImage.setImageUrl(imageUrl);
        issueImage.setFileName(image.getOriginalFilename());
        issueImage.setIssue(saved);

        imageRepo.save(issueImage);


        List<String> urls = List.of(imageUrl);

        return saved;

    }



    public Issue getIssueById(UUID id){
        return issueRepo.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Issue does not exist with id: " + id)
                );

    }

    public Issue updateStatus(UUID issueId, Status newStatus) {

        Issue issue = issueRepo.findById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Issue not found with id: " + issueId
                ));

        issue.setStatus(newStatus);

        return issueRepo.save(issue);
    }

    public Issue getById(UUID id){
        Issue issue= issueRepo.findById(id).orElseThrow(
                ()-> new ResourceNotFoundException("Issue Not found")
        );
        return issue;
    }
    public List<Issue>getByUser(User user){
        List<Issue>result=issueRepo.findByCreatedBy(user);
        return result;
    }

}

