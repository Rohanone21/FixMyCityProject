package com.example.FixMyCity.entity;

import lombok.Getter;

@Getter
public enum Category {
    POTHOLE, GARBAGE, STREETLIGHT, WATER, SEWAGE, OTHER
}

