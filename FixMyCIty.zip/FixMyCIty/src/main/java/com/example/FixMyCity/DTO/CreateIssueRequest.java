package com.example.FixMyCity.DTO;
import com.example.FixMyCity.entity.Category;

import lombok.Data;

@Data
public class CreateIssueRequest {
    private String title;
    private String description;
    private Category category;
    private Double latitude;
    private Double longitude;
    private String address;
}




