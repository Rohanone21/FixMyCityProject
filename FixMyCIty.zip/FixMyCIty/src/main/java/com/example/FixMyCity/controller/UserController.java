package com.example.FixMyCity.controller;


import com.example.FixMyCity.entity.Issue;
import com.example.FixMyCity.entity.User;
import com.example.FixMyCity.repository.IssueRepository;
import com.example.FixMyCity.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private IssueRepository issueRepository;

    @GetMapping("/get/{email}")
    public ResponseEntity<?> getSingleUser(@PathVariable String email){
        Optional<User> user= userRepository.findByEmail(email);

        return ResponseEntity.ok().body(user.get());

    }

    @GetMapping("/get/issues/{email}")
    public  ResponseEntity<?> getUserIssues(@PathVariable String email){
        Optional<User> user= userRepository.findByEmail(email);
        if(!user.isPresent()){
            return ResponseEntity.notFound().build();
        }
        List<Issue> userIssues= issueRepository.findByCreatedBy(user.get());

        return ResponseEntity.ok(userIssues);

    }

}
