import { Navigate, Outlet } from "react-router-dom";

const AuthLayout = ({ isAuthenticated }) => {
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : <Outlet />;
};

export default AuthLayout;
