import axios from "axios";
import { apiUrl } from "../constants/apiConstants";

export async function signUp(data) {
  try {
    const url = `${apiUrl}/auth/signup`;

    const response = await axios.post(url, data);

    return response.data;  
  } catch (error) {
    console.log("signUpError:", error);
    throw error;            
  }
}

export async function login1(data) {
  try {
    const url = `${apiUrl}/auth/login`;

    const response = await axios.post(url, data);

    return response.data;  
  } catch (error) {
    console.log("signUpError:", error);
    throw error;            
  }
}
