package com.example.FixMyCity.DTO;

import com.example.FixMyCity.entity.Category;
import com.example.FixMyCity.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IssueResponse {
    private UUID id;
    private String title;
    private String description;
    private String category;
    private Double latitude;
    private Double longitude;
    private String createdBy;
    private String status;

    private List<String> imageUrls;
}




