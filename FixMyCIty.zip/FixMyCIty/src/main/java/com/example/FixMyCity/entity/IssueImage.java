package com.example.FixMyCity.entity;
import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;


@Entity
@Table(name = "issue_images")
@Data
public class IssueImage {

    @Id
    @GeneratedValue
    private UUID id;

    private String imageUrl;

    private String fileName;

    private LocalDateTime uploadedAt = LocalDateTime.now();

    @ManyToOne
    @JoinColumn(name = "issue_id")
    private Issue issue;
}

