package com.example.FixMyCity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixMyCItyApplicationTests {

	@Test
	void contextLoads() {
	}

}
