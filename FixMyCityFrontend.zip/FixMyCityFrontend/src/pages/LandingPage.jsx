import React from "react";
import FeaturesSection from "../components/FeaturesSection";
import Footer from "../components/Footer";
import HeroSection from "../components/HeroSection";
import HowItWorksSection from "../components/HowItWorksSection";
import ImpactSection from "../components/ImpactSection";
import Navbar from "../components/Navbar";
import { useNavigate } from "react-router-dom";


export default function LandingPage() {

 const navigate =useNavigate();

 const onGetStarted=()=>{
    navigate("/login")
 }

  return (
    <div className="bg-white text-gray-900">
      {/* Navbar */}
      <div className="sticky top-0 z-50 bg-orange-white shadow-md">
        <Navbar 
         onGetStarted={onGetStarted}
         onLogin={onGetStarted}
        />
      </div>

      {/* Hero Section */}
      <section className="bg-orange-500 text-white">
        <HeroSection />
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <FeaturesSection />
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-orange-50">
        <div className="max-w-6xl mx-auto px-4">
          <HowItWorksSection />
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-20 bg-white">
        <ImpactSection 
          onGetStarted={onGetStarted}
        />
      </section>

      {/* Footer */}
      <footer className="bg-orange-600 text-white">
        <Footer />
      </footer>
    </div>
  );
}
