import React, { useState } from 'react';
import { X, MapPin, Search, ImageIcon } from 'lucide-react';

const IssueDialog = ({ open, onClose, onSubmit, loading }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("POTHOLE");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [address, setAddress] = useState("");
  const [image, setImage] = useState(null);
  const [addressSearch, setAddressSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const getUserLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported by your device");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude.toFixed(6);
        const lng = pos.coords.longitude.toFixed(6);
        setLatitude(lat);
        setLongitude(lng);
        reverseGeocode(lat, lng);
      },
      () => alert("Please allow location permission!")
    );
  };

  const reverseGeocode = async (lat, lng) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
        {
          headers: {
            'User-Agent': 'FixMyCity App'
          }
        }
      );
      const data = await response.json();
      if (data.display_name) {
        setAddress(data.display_name);
        setAddressSearch(data.display_name);
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);
    }
  };

  const searchAddress = async () => {
    if (!addressSearch.trim()) return;
    
    setSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(addressSearch)}&limit=5`,
        {
          headers: {
            'User-Agent': 'FixMyCity App'
          }
        }
      );
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error("Address search error:", error);
      alert("Failed to search address");
    } finally {
      setSearching(false);
    }
  };

  const selectAddress = (result) => {
    setLatitude(parseFloat(result.lat).toFixed(6));
    setLongitude(parseFloat(result.lon).toFixed(6));
    setAddress(result.display_name);
    setAddressSearch(result.display_name);
    setSearchResults([]);
  };

  const handleSubmit = () => {
    if (!title || !description || !latitude || !longitude || !address) {
      alert("Please fill all required fields including address");
      return;
    }

    if (!image) {
      alert("Please upload an image");
      return;
    }

    const formData = {
      title,
      description,
      category,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
      address,
      image
    };

    onSubmit(formData);
    
    // Reset form
    setTitle("");
    setDescription("");
    setCategory("POTHOLE");
    setLatitude("");
    setLongitude("");
    setAddress("");
    setAddressSearch("");
    setImage(null);
    setSearchResults([]);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white w-full max-w-2xl rounded-xl p-6 relative shadow-xl max-h-[90vh] overflow-y-auto">
        <button
          className="absolute top-3 right-3 text-gray-600 hover:text-black"
          onClick={onClose}
        >
          <X size={22} />
        </button>

        <h2 className="text-2xl font-bold text-orange-600 mb-4">Add New Issue</h2>

        <div>
          <label className="block font-medium">Title *</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border p-2 rounded mb-4"
            placeholder="Brief title of the issue"
            required
          />

          <label className="block font-medium">Description *</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full border p-2 rounded mb-4"
            rows={3}
            placeholder="Detailed description of the issue"
            required
          ></textarea>

          <label className="block font-medium">Category *</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full border p-2 rounded mb-4"
            required
          >
            <option value="POTHOLE">Pothole</option>
            <option value="STREETLIGHT">Street Light</option>
            <option value="GARBAGE">Garbage</option>
            <option value="DRAINAGE">Drainage</option>
            <option value="ROAD_DAMAGE">Road Damage</option>
            <option value="WATER_SUPPLY">Water Supply</option>
            <option value="OTHER">Other</option>
          </select>

          <div className="mb-4">
            <label className="block font-medium mb-2">Search Address *</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={addressSearch}
                onChange={(e) => setAddressSearch(e.target.value)}
                placeholder="Enter address or landmark"
                className="flex-1 border p-2 rounded"
                required
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    searchAddress();
                  }
                }}
              />
              <button
                type="button"
                onClick={searchAddress}
                disabled={searching}
                className="bg-blue-600 text-white px-4 py-2 rounded flex items-center gap-2 hover:bg-blue-700 disabled:bg-gray-400"
              >
                <Search size={18} />
                {searching ? "..." : "Search"}
              </button>
            </div>

            {searchResults.length > 0 && (
              <div className="mt-2 border rounded max-h-48 overflow-y-auto bg-white shadow-lg">
                {searchResults.map((result, idx) => (
                  <div
                    key={idx}
                    onClick={() => selectAddress(result)}
                    className="p-3 hover:bg-orange-50 cursor-pointer border-b last:border-b-0"
                  >
                    <p className="text-sm font-medium">{result.display_name}</p>
                    <p className="text-xs text-gray-500">
                      {parseFloat(result.lat).toFixed(6)}, {parseFloat(result.lon).toFixed(6)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {address && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded">
              <p className="text-sm font-medium text-green-800">Selected Address:</p>
              <p className="text-sm text-green-700">{address}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block font-medium">Latitude *</label>
              <input
                type="number"
                step="any"
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                className="w-full border p-2 rounded"
                placeholder="18.5204"
                required
              />
            </div>
            <div>
              <label className="block font-medium">Longitude *</label>
              <input
                type="number"
                step="any"
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                className="w-full border p-2 rounded"
                placeholder="73.8567"
                required
              />
            </div>
          </div>

          <button
            type="button"
            onClick={getUserLocation}
            className="w-full mb-4 bg-green-600 text-white px-4 py-2 rounded flex items-center justify-center gap-2 hover:bg-green-700"
          >
            <MapPin size={18} /> Use My Current Location
          </button>

          <label className="block font-medium">Upload Image *</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files[0];
              if (file) {
                setImage(file);
              }
            }}
            className="w-full mb-4"
            required
          />
          {image && (
            <div className="mb-4">
              <p className="text-sm text-green-600">Selected image: {image.name}</p>
              <img 
                src={URL.createObjectURL(image)} 
                alt="Preview" 
                className="mt-2 w-full h-48 object-cover rounded-lg"
              />
            </div>
          )}

          <button
            type="button"
            onClick={handleSubmit}
            disabled={loading}
            className={`w-full text-white py-3 rounded mt-2 transition font-semibold ${
              loading ? "bg-gray-400" : "bg-orange-600 hover:bg-orange-700"
            }`}
          >
            {loading ? "Submitting..." : "Submit Issue"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default IssueDialog;