package com.example.FixMyCity.entity;

public enum Status {
    OPEN, IN_PROGRESS, RESOLVED
}
