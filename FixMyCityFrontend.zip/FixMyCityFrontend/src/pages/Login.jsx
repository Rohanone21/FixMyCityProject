import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login1 } from "../services/AuthService";
import { useAuth } from "../hooks/useAuth";

export default function LoginPage() {
  const navigate = useNavigate();
  const { auth, login, logout } = useAuth();

  

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading,setLoading]=useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      setLoading(true)
      const resp = await login1({
        email: email,
        password: password,
      });
      console.log('login resp',resp)

      // Save JWT token
      localStorage.setItem("token", resp.token);
      localStorage.setItem("userEmail",resp.email);

      // Navigate to home/dashboard
      login(true);
      navigate("/dashboard");
      setLoading(false)
    } catch (error) {
      console.log("Login error:", error);
      setLoading(false)
    }
  };

  const goToSignup = () => {
    navigate("/signup");
  };

  return (
    <div className="flex h-screen">
      {/* Left side */}
      <div className="w-1/2 bg-white flex flex-col items-center justify-center p-10">
        <img src="./logo1.png" alt="App Logo" className="w-32 h-32 object-contain mb-4" />
        <h1 className="text-4xl font-bold text-orange-600">FixMyCity</h1>
      </div>

      {/* Right side */}
      <div className="w-1/2 bg-orange-500 flex items-center justify-center p-10 text-white">
        <form
          className="bg-white text-gray-800 p-8 rounded-2xl shadow-md w-80"
          onSubmit={handleLogin}
        >
          <h2 className="text-2xl font-semibold mb-6 text-center text-orange-600">
            Login
          </h2>

          <label className="block mb-2 font-medium">Email</label>
          <input
            type="email"
            className="w-full p-2 border rounded mb-4"
            placeholder="Enter your email"
            onChange={(e) => setEmail(e.target.value)}
            value={email}
            required
          />

          <label className="block mb-2 font-medium">Password</label>
          <input
            type="password"
            className="w-full p-2 border rounded mb-6"
            placeholder="Enter your password"
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            required
          />

          <button
            type="submit"
             disabled={loading}
  className={`w-full text-white py-2 rounded transition 
    ${loading ? "bg-gray-400 cursor-not-allowed" : "bg-orange-600 hover:bg-orange-700"}`}
          >
            {
              loading? "Loading...." : "Login"
            }
          </button>

          <div className="flex p-2 items-center justify-center text-sm">
            Don't Have An Account?
            <span
              className="text-blue-500 hover:cursor-pointer pl-1"
              onClick={goToSignup}
            >
              Sign Up
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}
